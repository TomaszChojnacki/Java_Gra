CREATE TABLE Gra (
    GraID INT PRIMARY KEY,
    SesjaID INT
);

CREATE TABLE Gracze (
    GraczID INT PRIMARY KEY,
    NazwaGracza VARCHAR2(20) UNIQUE NOT NULL,
    Haslo VARCHAR2(20) NOT NULL,
    PunktyGracza INT DEFAULT 0,
    PoziomGracza INT DEFAULT 1,
    IloscZdobytychPunktow INT DEFAULT 0,
    PoziomZdrowia INT DEFAULT 100,
    GraID INT,
    FOREIGN KEY (GraID) REFERENCES Gra(GraID) 
);

CREATE TABLE Tury (
    TuraID INT PRIMARY KEY,
    GraczID INT,
    NumerTury INT,
    CzasTrwania INT, 
    FOREIGN KEY (GraczID) REFERENCES Gracze(GraczID)
);

CREATE TABLE StatystykiGracza (
    StatystykiID INT PRIMARY KEY,
    GraczID INT,
    Zabojstwa INT DEFAULT 0,
    Smierci INT DEFAULT 0,
    Wygrane INT DEFAULT 0,
    FOREIGN KEY (GraczID) REFERENCES Gracze(GraczID)
);

CREATE TABLE IloscRuchow (
    IDRuchu INT PRIMARY KEY,
    GraczID INT,
    NumerTury INT,
    IloscRuchow INT,
    FOREIGN KEY (GraczID) REFERENCES Gracze(GraczID)
);

CREATE TABLE Ranking (
    RankingID INT PRIMARY KEY,
    GraID INT,
    NazwaRankingu VARCHAR2(50), 
    FOREIGN KEY (GraID) REFERENCES Gra(GraID)
);

CREATE TABLE Punkty (
    PunktyID INT PRIMARY KEY,
    RankingID INT,
    GraczID INT,
    IloscPunktow INT,
    FOREIGN KEY (RankingID) REFERENCES Ranking(RankingID)
);


