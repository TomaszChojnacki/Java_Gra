-- Insert do tabeli Gra
INSERT INTO Gra (GraID, SesjaID) VALUES (1, 1);
INSERT INTO Gra (GraID, SesjaID) VALUES (2, 1);
INSERT INTO Gra (GraID, SesjaID) VALUES (3, 1);

-- Insert do tabeli Gracze
INSERT INTO Gracze (GraczID, NazwaGracza, Haslo, GraID) VALUES (1, 'Gracz1', 'haslo123', 1);
INSERT INTO Gracze (GraczID, NazwaGracza, Haslo, GraID) VALUES (2, 'Gracz2', 'tajnehaslo', 1);
INSERT INTO Gracze (GraczID, NazwaGracza, Haslo, GraID) VALUES (3, 'Gracz3', 'innehhaslo', 2);
INSERT INTO Gracze (GraczID, NazwaGracza, Haslo, GraID) VALUES (4, 'Gracz4', 'topsecretpass', 2);
INSERT INTO Gracze (GraczID, NazwaGracza, Haslo, GraID) VALUES (5, 'Gracz5', 'haslo123', 3);


-- Insert do tabeli Tury
INSERT INTO Tury (TuraID, GraczID, NumerTury, CzasTrwania) VALUES (1, 1, 1, 60);
INSERT INTO Tury (TuraID, GraczID, NumerTury, CzasTrwania) VALUES (2, 2, 1, 60);
INSERT INTO Tury (TuraID, GraczID, NumerTury, CzasTrwania) VALUES (3, 3, 1, 60);
INSERT INTO Tury (TuraID, GraczID, NumerTury, CzasTrwania) VALUES (4, 4, 1, 60);
INSERT INTO Tury (TuraID, GraczID, NumerTury, CzasTrwania) VALUES (5, 5, 1, 60);


-- Insert do tabeli IloscRuchow
INSERT INTO IloscRuchow (IDRuchu, GraczID, NumerTury, IloscRuchow) VALUES (1, 1, 1, 5);
INSERT INTO IloscRuchow (IDRuchu, GraczID, NumerTury, IloscRuchow) VALUES (2, 2, 1, 4);
INSERT INTO IloscRuchow (IDRuchu, GraczID, NumerTury, IloscRuchow) VALUES (3, 3, 1, 6);
INSERT INTO IloscRuchow (IDRuchu, GraczID, NumerTury, IloscRuchow) VALUES (4, 4, 1, 3);
INSERT INTO IloscRuchow (IDRuchu, GraczID, NumerTury, IloscRuchow) VALUES (5, 5, 1, 4);


-- Insert do tabeli Ranking
INSERT INTO Ranking (RankingID, GraID, NazwaRankingu) VALUES (1, 1, 'Ranking Ogolny');
INSERT INTO Ranking (RankingID, GraID, NazwaRankingu) VALUES (2, 2, 'Ranking Ogolny');
INSERT INTO Ranking (RankingID, GraID, NazwaRankingu) VALUES (3, 3, 'Ranking Ogolny');


-- Insert do tabeli Punkty
INSERT INTO Punkty (PunktyID, RankingID, GraczID, IloscPunktow) VALUES (1, 1, 1, 100);
INSERT INTO Punkty (PunktyID, RankingID, GraczID, IloscPunktow) VALUES (2, 1, 2, 80);
INSERT INTO Punkty (PunktyID, RankingID, GraczID, IloscPunktow) VALUES (3, 2, 3, 90);
INSERT INTO Punkty (PunktyID, RankingID, GraczID, IloscPunktow) VALUES (4, 2, 4, 70);
INSERT INTO Punkty (PunktyID, RankingID, GraczID, IloscPunktow) VALUES (5, 3, 5, 110);


-- Insert do tabeli StatystykiGracza
INSERT INTO StatystykiGracza (StatystykiID, GraczID, Zabojstwa, Smierci, Wygrane) VALUES (1, 1, 3, 1, 1);
INSERT INTO StatystykiGracza (StatystykiID, GraczID, Zabojstwa, Smierci, Wygrane) VALUES (2, 2, 2, 2, 0);
INSERT INTO StatystykiGracza (StatystykiID, GraczID, Zabojstwa, Smierci, Wygrane) VALUES (3, 3, 1, 2, 0);
INSERT INTO StatystykiGracza (StatystykiID, GraczID, Zabojstwa, Smierci, Wygrane) VALUES (4, 4, 2, 1, 1);
INSERT INTO StatystykiGracza (StatystykiID, GraczID, Zabojstwa, Smierci, Wygrane) VALUES (5, 5, 4, 0, 1);
