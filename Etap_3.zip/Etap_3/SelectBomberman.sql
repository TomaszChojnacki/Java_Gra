--1. Wybierz wszystkich graczy razem z ich statystykami i iloscia punktow gdzie ilosc punktow jest wieksza niz 80
SELECT Gracze.*, StatystykiGracza.*, Punkty.IloscPunktow
FROM Gracze
JOIN StatystykiGracza ON Gracze.GraczID = StatystykiGracza.GraczID
JOIN Punkty ON Gracze.GraczID = Punkty.GraczID
WHERE Punkty.IloscPunktow > 80;


--2. Wybierz nazwe gracza razem z maksymalna ilosca zabojstw grupujac wyniki po nazwie gracza
SELECT Gracze.NazwaGracza, MAX(StatystykiGracza.Zabojstwa) AS NajwiekszaIloscZabojstw
FROM Gracze
JOIN StatystykiGracza ON Gracze.GraczID = StatystykiGracza.GraczID
GROUP BY Gracze.NazwaGracza;

--3. Zapytanie o graczy i ich statystyki w danej grze
SELECT Gracze.NazwaGracza, Gracze.PunktyGracza, StatystykiGracza.Zabojstwa, StatystykiGracza.Smierci
FROM Gracze
JOIN StatystykiGracza ON Gracze.GraczID = StatystykiGracza.GraczID
WHERE Gracze.GraID = 1;

--4. Zapytanie o ranking ogolny w danej sesji gry z uwzgl�dnieniem nazw graczy
SELECT Gracze.NazwaGracza, Punkty.IloscPunktow, Ranking.NazwaRankingu
FROM Gracze
JOIN Punkty ON Gracze.GraczID = Punkty.GraczID
JOIN Ranking ON Punkty.RankingID = Ranking.RankingID
WHERE Gracze.GraID = 1
ORDER BY Punkty.IloscPunktow DESC;

--5. Zapytanie o sume zabojstw smierci i wygranych dla wszystkich graczy
SELECT Gracze.NazwaGracza, SUM(StatystykiGracza.Zabojstwa) AS SumaZabojstw, 
    SUM(StatystykiGracza.Smierci) AS SumaSmierci, SUM(StatystykiGracza.Wygrane) AS SumaWygran
FROM Gracze
JOIN StatystykiGracza ON Gracze.GraczID = StatystykiGracza.GraczID
GROUP BY Gracze.NazwaGracza;













