DROP TABLE Punkty;
DROP TABLE Ranking;
DROP TABLE IloscRuchow;
DROP TABLE StatystykiGracza;
DROP TABLE Tury;
DROP TABLE Gracze;
DROP TABLE Gra;
