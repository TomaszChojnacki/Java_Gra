import java.io.*;
import java.net.*;

public class Klient {
    public static void main(String[] args) {
        String serverAddress = "localhost";
        int portNumber = 12345;

        try (
                Socket socket = new Socket(serverAddress, portNumber);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("Polaczono z serwerem. Mozesz rozpoczac komunikacje.");

            String serverResponse;
            while ((serverResponse = in.readLine()) != null) {
                System.out.println(serverResponse);

                if (serverResponse.equalsIgnoreCase("Serwer: Zakonczono polaczenie.")) {
                    break;
                }

                System.out.print("Twoja wiadomosc: ");
                String userInput = consoleInput.readLine();
                out.println(userInput);

                if (userInput.equalsIgnoreCase("exit")) {
                    break;
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Nieznany host: " + serverAddress);
        } catch (IOException e) {
            System.err.println("Blad podczas polaczenia z serwerem.");
        }
    }
}
