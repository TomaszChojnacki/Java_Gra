import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        int portNumber = 12345;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            System.out.println("Serwer nasluchuje na porcie " + portNumber + "...");

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

                    System.out.println("Klient polaczyl sie z serwerem.");
                    out.println("Witaj! Napisz 'exit', aby zakonczyc polaczenie.");

                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        System.out.println("Klient: " + inputLine);
                        if (inputLine.equalsIgnoreCase("exit")) {
                            break;
                        }

                        // Odpowiedź serwera
                        String response = "Serwer: Otrzymalem twoja wiadomosc: " + inputLine;
                        out.println(response);
                        System.out.println(response);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
